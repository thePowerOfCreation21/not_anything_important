<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReportCardExamScoreController extends Controller
{
    //
}
