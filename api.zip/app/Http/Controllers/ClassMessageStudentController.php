<?php

namespace App\Http\Controllers;

use App\Actions\ClassMessageStudentAction;
use Illuminate\Http\Request;

class ClassMessageStudentController extends Controller
{
    public function getByStudent (Request $request){
        return response()->json(
            (new ClassMessageStudentAction())
                ->setRequest($request)
                ->mergeQueryWith(['student_id' => $request->user()->id])
                ->makeEloquent()
                ->getByRequestAndEloquent()
        );
    }
}
