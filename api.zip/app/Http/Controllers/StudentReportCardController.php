<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StudentReportCardController extends Controller
{
    //
}
