<?php

namespace App\Actions;

use Genocide\Radiocrud\Services\ActionService\ActionService;

class MessageStudentAction extends ActionService
{
    public function __construct()
    {
        
        parent::__construct();
    }
}
